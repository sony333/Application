@extends('layouts.main')

@section('container')

<h1 class="head">Welcome Guest</h1>

@endsection